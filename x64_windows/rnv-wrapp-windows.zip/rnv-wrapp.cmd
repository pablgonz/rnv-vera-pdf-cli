@echo off
where texlua >nul 2>nul
if errorlevel 1 (
    echo Error: texlua not found in PATH. >&2
    echo rnv-wrapp requires a TeX Live installation with texlua available. >&2
    exit /b 1
)
texlua "%~dp0rnv-wrapp.lua" %*
